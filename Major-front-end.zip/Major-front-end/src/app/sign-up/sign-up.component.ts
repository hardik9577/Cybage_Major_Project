import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroupDirective, NgForm, Validators, FormGroup } from '@angular/forms';
import { Iuser } from '../iuser';
import { SharedService } from '../shared.service';


@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.scss']
})
export class SignUpComponent implements OnInit {

  showDetails: boolean = false;
  minDate: Date;
  maxDate: Date;
  new_user : any;

  onStrengthChanged(strength: number) {
    console.log('password strength = ', strength);
  }

  constructor(private service : SharedService) {

    this.maxDate = new Date();
  }

  ngOnInit(): void {
   
  }


  // signUpForm = new FormGroup({
  //   firstName: new FormControl('', [Validators.required]),
  //   lastName: new FormControl('', [Validators.required]),
  //   contactNo: new FormControl('', [Validators.required]),
  //   gender: new FormControl('', [Validators.required]),
  //   email: new FormControl('', [Validators.required, Validators.email]),
  //   password: new FormControl('', [Validators.required]),
  //   dob: new FormControl('', [Validators.required]),
  // });

  firstName = new FormControl('', [Validators.required]);
  lastName = new FormControl('', [Validators.required]);
  contactNo = new FormControl('', [Validators.required]);
  gender = new FormControl('', [Validators.required]);
  email = new FormControl('', [Validators.required, Validators.email]);
  password = new FormControl('', [Validators.required]);
  dateOfBirth = new FormControl('', [Validators.required]);



  onSubmit() {
    if (this.firstName.valid && this.lastName.valid && this.contactNo.valid && this.gender.valid && this.email.valid && this.password.valid && this.dateOfBirth.valid) {

        var val = {
        firstName: this.firstName.value,
        lastName: this.lastName.value,
        email: this.email.value,
        password: this.password.value,
        dateOfBirth: this.dateOfBirth.value,
        contactNo: this.contactNo.value,
        gender: this.gender.value,
        isVerified: false,
      }
      console.log(val);
      this.service.addUser(val).subscribe(res=>{
        alert(res.toString());
      });
    }
  }

}
