export interface Iuser {
    firstName: string;
    lastName: string;
    contactNo: string;
    gender: string;
    email: string;
    password: string;
    dob: string;
}
