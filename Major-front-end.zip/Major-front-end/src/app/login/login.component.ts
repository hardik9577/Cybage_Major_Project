import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {FormControl, FormGroupDirective, NgForm, Validators} from '@angular/forms';
import {ErrorStateMatcher} from '@angular/material/core';
import { SharedService } from '../shared.service';




@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  showDetails: boolean = false;

  onStrengthChanged(strength: number) {
    console.log('password strength = ', strength);
  }

  constructor(private router: Router, private service : SharedService) { }

  userList:any=[];

  ngOnInit(): void {

  }

  username = new FormControl('', [Validators.required, Validators.email]);
  password = new FormControl('', [Validators.required]);

  LoginUser() {
    console.log(this.username.value);
    console.log(this.password.value);
    var username = this.username.value;
    var password = this.password.value
    var val = {
      username : this.username.value,
      password : this.password.value
    }
    this.service.login1(username, password).subscribe(res=>{
      
      console.log(res);
      alert(res.toString());
      // console.log(this.userList);
    })
    // this.router.navigateByUrl('')
  }

 
}